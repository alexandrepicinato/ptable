export function distribuicaoatomica(numeroa){
    var list = [
      2,
      8,
      18,
      32,
      32,
      18,
      8]
      var sequence =[]
      var number =numeroa
  
  
      for (var i =0 ; i< list.length ; i ++){
        if (number- list[i] > 0 ){
          sequence.push(list[i])
          number = number- list[i]
        }
        else{
          if(number > 0){
            sequence.push(number)
            number = number- list[i]
          }
          else{
  
          }
        }
      }
      return sequence
  }

  export default function FamilyByPosition(posx){
    var metais =["3","11","19","37","55","87"]
    var metaisalcalinos =["4","12","20","38","56","88"]
    var semimetais =["5","14","32","33","51","52","84"]
    var gasesnobres =["2","10","18","36","54","86","118"]
    var halogenos =["9","17","35","53","85","117"]
    var naometais =["6","7","8","15","16","34"]
    console.log(posx)
    if (metais.indexOf(posx) > -1) {
      return 'metal'
    }
    else if (metaisalcalinos.indexOf(posx) > -1) {
      return 'metaisalcalinos'
    }
    else if (semimetais.indexOf(posx) > -1) {
      return 'semimetais'
    }
    else if (halogenos.indexOf(posx) > -1) {
      return 'halogenos'
    }
    else if (naometais.indexOf(posx) > -1) {
      return 'naometais'
    }
    else if (gasesnobres.indexOf(posx) > -1) {
      return 'gasesnobres'
    }
    else{
      return "metaldetransicao"
    }
  }