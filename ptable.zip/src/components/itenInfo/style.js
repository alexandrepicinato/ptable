import styled from "styled-components";

const ContainerData = styled.div `

`
const OrbitContainer = styled.div `

`
export{
    ContainerData,
    OrbitContainer
}